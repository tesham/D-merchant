package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.Cart;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface CartRepository extends CrudRepository<Cart,Integer> {
    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE Cart b set b.user_id=:user_id where b.cart_id=:cart_id")
    void updateCartDeleverUser(@Param("user_id") Integer user_id,@Param("cart_id") Integer cart_id);
}
