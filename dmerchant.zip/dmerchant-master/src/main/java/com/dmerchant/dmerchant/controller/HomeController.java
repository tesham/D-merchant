package com.dmerchant.dmerchant.controller;

import com.dmerchant.dmerchant.model.Product;
import com.dmerchant.dmerchant.model.ProductCategory;
import com.dmerchant.dmerchant.model.ProductSubCategory;
import com.dmerchant.dmerchant.repository.ProductCategoryRepository;
import com.dmerchant.dmerchant.repository.ProductRepository;
import com.dmerchant.dmerchant.repository.ProductSubCategoryRepository;
import com.dmerchant.dmerchant.session.Utils;
import com.dmerchant.dmerchant.utility.CartInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
//@SessionAttributes("list")
@RequestMapping("")
public class HomeController {
//    @Autowired
//    ProductRepository productRepository;
    @Autowired
    ProductSubCategoryRepository productSubCategoryRepository;
    @Autowired
    ProductCategoryRepository productCategoryRepository;

//    @ModelAttribute
//    public void addSessionAttributes(Model model){
//        //System.out.println("inside asdsadasdadas");
//        List<ProductSubCategory> productSubCategories=(List<ProductSubCategory>)productSubCategoryRepository.findAll();
//        model.addAttribute("allList",productSubCategories);
//    }

    @GetMapping("")
    public ModelAndView home(HttpServletRequest request){
        ModelAndView model=new ModelAndView("home");
        model.addObject("companyName","D-Merchant");
       // List<Product> products=(List<Product>)productRepository.findAll();
        List<ProductCategory> productCategories=( List<ProductCategory>)productCategoryRepository.findAll();
       // List<ProductSubCategory> productSubCategories=(List<ProductSubCategory>)productSubCategoryRepository.findAll();
       // model.addObject("allList",productSubCategories);
        CartInfo cartInfo= Utils.getCartInSession(request);
     //   request.getSession().setAttribute("subCategoryList",productSubCategories);
        request.getSession().setAttribute("categoryList",productCategories);
        return model;
        //return "home";
    }

}
