package com.dmerchant.dmerchant;

import com.dmerchant.dmerchant.utility.AppUserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled=true)
@EnableWebSecurity
@ComponentScan
public class WebSecurity extends WebSecurityConfigurerAdapter {

    @Autowired
    AppUserDetailService appUserDetailService;

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.csrf().disable();
        httpSecurity.authorizeRequests().antMatchers("/admin/**").authenticated()
                .anyRequest().permitAll()
                .and()
                .formLogin().loginPage("/login")
                .defaultSuccessUrl("/success",true)
                .failureUrl("/login?error=true")
                .and()
                .logout();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth)  throws Exception{
        auth.userDetailsService(appUserDetailService)
               .passwordEncoder(getPasswordEncoder());
               // .passwordEncoder(bCryptPasswordEncoder);
    }

    private PasswordEncoder getPasswordEncoder() {
        return new PasswordEncoder() {

            @Override
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
                // TODO Auto-generated method stub
                if(rawPassword.toString().equals(encodedPassword)) {
                    return true;
                }else {
                    return false;
                }

            }

            @Override
            public String encode(CharSequence rawPassword) {
                // TODO Auto-generated method stub
                return rawPassword.toString();
            }
        };
    }
}
