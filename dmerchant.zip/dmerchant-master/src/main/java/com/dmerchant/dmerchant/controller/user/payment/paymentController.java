package com.dmerchant.dmerchant.controller.user.payment;

import com.dmerchant.dmerchant.repository.CartProductRepository;
import com.dmerchant.dmerchant.repository.CartRepository;
import com.dmerchant.dmerchant.repository.OrderInfoRepository;
import com.dmerchant.dmerchant.session.Utils;
import com.dmerchant.dmerchant.utility.CartInfo;
import com.dmerchant.dmerchant.utility.OrderDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("payment")
public class paymentController {
    
    @PostMapping("paymentMethod")
    public String getPaymentMethod(
                                    @RequestParam("name") String name,
                                   @RequestParam("email") String email,
                                   @RequestParam("address") String address,
                                   @RequestParam("mobile") String mobile,
                                    HttpServletRequest request
                                    ){

        OrderDetails orderDetails=new OrderDetails(name,mobile,email,address);
        CartInfo cartInfo= Utils.getCartInSession(request);
        cartInfo.setOrderDetails(orderDetails);
        return "redirect:/paymentTest/paymentMethodSelectIndex";
    }
}
