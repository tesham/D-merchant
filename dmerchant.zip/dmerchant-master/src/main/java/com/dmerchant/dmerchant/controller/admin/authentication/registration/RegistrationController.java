package com.dmerchant.dmerchant.controller.admin.authentication.registration;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("")
public class RegistrationController {
    @GetMapping("/registration")
    public ModelAndView registrationIndex(){
        try {
            ModelAndView model = new ModelAndView("Authentication/Registration/RegistrationIndex");
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }
}
