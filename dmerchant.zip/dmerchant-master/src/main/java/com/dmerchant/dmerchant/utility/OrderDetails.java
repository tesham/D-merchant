package com.dmerchant.dmerchant.utility;

public class OrderDetails {
    private String customerName;
    private String customerPhone;
    private String customerMail;
    private String customerAddress;

    public OrderDetails(){}
    public OrderDetails(
            String name,String phn,String mail,String address
    ){
        this.customerName=name;
        this.customerMail=mail;
        this.customerPhone=phn;
        this.customerAddress=address;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getCustomerMail() {
        return customerMail;
    }

    public void setCustomerMail(String customerMail) {
        this.customerMail = customerMail;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }
}
