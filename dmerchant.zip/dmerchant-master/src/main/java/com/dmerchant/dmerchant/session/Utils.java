package com.dmerchant.dmerchant.session;

import com.dmerchant.dmerchant.model.CartProduct;
import com.dmerchant.dmerchant.utility.CartInfo;

import javax.servlet.http.HttpServletRequest;

public class Utils {

    public static CartInfo getCartInSession(HttpServletRequest request){
        CartInfo cartInfo=(CartInfo)request.getSession().getAttribute("myCart");
        if(cartInfo==null){
            cartInfo=new CartInfo();
            request.getSession().setAttribute("myCart", cartInfo);
        }

        return cartInfo;
    }


}
