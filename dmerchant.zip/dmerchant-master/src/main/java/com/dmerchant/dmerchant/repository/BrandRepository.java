package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.Brand;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface BrandRepository extends CrudRepository<Brand,Integer> {
    @Query("select b from Brand b where b.brand_id=:id")
    Brand findByBrand_id(@Param("id") Integer id);

    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE Brand b set b.brand_name=:brandName where b.brand_id=:id")
    void updateBrandName(@Param("id") Integer id,
                         @Param("brandName") String brandName);

    @Modifying
    @Transactional(readOnly = false)
    @Query("DELETE from Brand b WHERE b.brand_id=:id")
    void deleteByBrand_id(@Param("id") Integer id);
}
