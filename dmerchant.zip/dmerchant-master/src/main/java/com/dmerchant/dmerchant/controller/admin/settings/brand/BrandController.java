package com.dmerchant.dmerchant.controller.admin.settings.brand;

import com.dmerchant.dmerchant.model.Brand;
import com.dmerchant.dmerchant.repository.BrandRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class BrandController {
    @Autowired
    BrandRepository brandRepository;

    @GetMapping("/settings/brandList")
    public ModelAndView brandList(){
        try {
            ModelAndView model = new ModelAndView("Settings/Brand/BrandList");
            List<Brand> brands = (List<Brand>)brandRepository.findAll();
            model.addObject("brandList", brands);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/addBrand")
    public ModelAndView addBrand(@RequestParam("brandName") String brandName){
        try {
            Brand brand = new Brand();
            brand.setBrand_name(brandName);
            brandRepository.save(brand);
            return new ModelAndView("redirect:/admin/settings/brandList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @GetMapping("/settings/editBrandByID/{id}")
    public ModelAndView editBrandByID(@PathVariable("id") Integer brandID){
        try {
            ModelAndView model = new ModelAndView("Settings/Brand/EditBrand");
            Brand brand = brandRepository.findByBrand_id(brandID);
            model.addObject("brandByID", brand);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/editBrand")
    public ModelAndView SubmitEditBrand(@RequestParam("brandID") Integer brandID,
                                        @RequestParam("brandName") String brandName){
        try {
//            Brand brand = new Brand();
            brandRepository.updateBrandName(brandID,brandName);
            return new ModelAndView("redirect:/admin/settings/brandList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @GetMapping("/settings/deleteBrandByID/{id}")
    public ModelAndView deleteBrandByID(@PathVariable("id") Integer branchID){
        try {
            brandRepository.deleteByBrand_id(branchID);
            return new ModelAndView("redirect:/admin/settings/brandList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageBrandCanNotBeDeleted");
        }
    }

}
