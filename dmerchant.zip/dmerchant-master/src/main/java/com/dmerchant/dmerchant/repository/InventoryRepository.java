package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.Inventory;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface InventoryRepository extends CrudRepository<Inventory,Integer> {

    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE Inventory b set b.totalStocked=:totalStock where b.inventory_id=:id")
    void updateProductInventory(
            @Param("id") Integer id,
            @Param("totalStock") Integer totalStock
    );
}
