package com.dmerchant.dmerchant.controller.admin.products;

import com.dmerchant.dmerchant.model.*;
import com.dmerchant.dmerchant.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class addProductController {
    @Autowired
    InventoryRepository inventoryRepository;
    @Autowired
    ProductCategoryRepository productCategoryRepository;
    @Autowired
    ProductSubCategoryRepository productSubCategoryRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ProductImageRepository productImageRepository;
    @Autowired
    BrandRepository brandRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    ProductStarRepository productStarRepository;

    @GetMapping("/selectSubCategory/{subCat}")
    public List<ProductSubCategory> getSubCategory(
            @PathVariable("subCat") Integer catId
    ){
        List<ProductSubCategory> productSubCategoryList = (List<ProductSubCategory>)productSubCategoryRepository.getAllByProduct_category_id(catId);
        return productSubCategoryList;
    }

    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/addProduct")
    public String addProduct(@RequestParam("productSN") String productSN,
                                   @RequestParam("productName") String productName,
                                   @RequestParam("productCategory") Integer productCategory,
                                   @RequestParam("productSubCategory") Integer productSubCategory,
                                   @RequestParam("productBrand") Integer productBrand,
                                   @RequestParam("productPrice") Double productPrice,
                                   @RequestParam("productDiscountAvailable") Boolean productDiscountAvailable,
                                   @RequestParam("productDiscount") Double productDiscount,
                                   @RequestParam("productDescription") String productDescription,
                                   @RequestParam("file") MultipartFile productImage,
                                   @RequestParam("totalStock") Integer totalStock,
                                    HttpServletRequest request
                             ){
        try {
//            ModelAndView model = new ModelAndView("Products/addProduct");
//            return model;
//            save to inventory
            Inventory inventory = new Inventory();
            inventory.setTotalStocked(totalStock);
            inventory.setTotalSold(0);
            inventory.setAvailable(true);
            inventory.setCanSell(true);
            inventoryRepository.save(inventory);

            //product star initialize
            ProductStar productStar=new ProductStar();
            productStar.setStar_sum(5);
            productStar.setStar_given_count(1);
            productStar.setRating(5);
            productStarRepository.save(productStar);

//            save to product
            Product product = new Product();
            product.setBrand_id(productBrand);
            product.setProduct_sub_category_id(productSubCategory);
            product.setInventory_id(inventory.getInventory_id());
            product.setProductSN(productSN);
            product.setProductName(productName);
            product.setProductPrice(productPrice);
            product.setProduct_review_star_id(productStar.getProduct_review_star_id());
            product.setDiscountAvailable(productDiscountAvailable);
            product.setProductDescription(productDescription);
            product.setProductDiscount(productDiscount);
            product.setInsert_time(new Date());
            String userName=(String) request.getSession().getAttribute("userName");
            User user=userRepository.findUser_nameAndAndIs_active(userName).get();
            if(user!=null){
                product.setUser_id(user.getUser_id());
            }
            productRepository.save(product);
//            save to product image
             ProductImage image = new ProductImage();
             image.setProduct_id(product.getProduct_id());
             image.setImage(productImage.getBytes());
             image.setIs_active(1);
             image.setIs_title(1);
             image.setCreateDate(new Date());
             productImageRepository.save(image);
//            setImages(productImage) to product image table

            return "redirect:/admin/productList";
        }catch (Exception ex){
            System.err.println(ex);
            //return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhileLabel");
        }
        return "d";
    }
}
