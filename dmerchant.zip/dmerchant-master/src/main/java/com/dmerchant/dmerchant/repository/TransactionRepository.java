package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.Transaction;
import org.springframework.data.repository.CrudRepository;

public interface TransactionRepository extends CrudRepository<Transaction,Integer> {
}
