package com.dmerchant.dmerchant.controller.admin.settings.userRole;

import com.dmerchant.dmerchant.model.Role;
import com.dmerchant.dmerchant.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class UserRoleSettingsController {
    @Autowired
    UserRoleRepository userRoleRepository;

    @GetMapping("/settings/userRoleList")
    public ModelAndView userRoleList(){
        try {
            ModelAndView model = new ModelAndView("Settings/UserRole/UserRoleList");
            List<Role> roles = (List<Role>)userRoleRepository.findAll();
            model.addObject("roleList",roles);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/addUserRole")
    public ModelAndView addUserRole(@RequestParam("userRoleName") String userRoleName,
                                    @RequestParam("isActive") Boolean isActive){
        try {
            Role role = new Role();
            role.setRole(userRoleName);
            role.setActive(isActive);
            userRoleRepository.save(role);
            return new ModelAndView("redirect:/admin/settings/userRoleList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

//    @GetMapping("/settings/editUserRoleByID/{id}")
//    public ModelAndView editUserRoleByID(@PathVariable("id") Integer userRoleID){
//        try {
//            ModelAndView model = new ModelAndView("Settings/UserRole/EditUserRole");
//            Role role = userRoleRepository.findByRole_id(userRoleID);
//            model.addObject("userRoleByID",role);
//            return model;
//        }catch (Exception ex){
//            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
//        }
//    }
//
//    @PostMapping("/settings/editUserRole")
//    public ModelAndView editUserRole(@RequestParam("userRoleID") Integer userRoleID,
//                                     @RequestParam("userRoleName") String userRoleName,
//                                     @RequestParam("isActive") Boolean isActive){
//        try {
////            userRoleRepository.updateUserRoleByID(userRoleID,userRoleName,isActive);
////            userRoleRepository.updateUserRoleByID(userRoleID,userRoleName,isActive);
//            return new ModelAndView("redirect:/admin/settings/userRoleList");
//        }catch (Exception ex){
//            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
//        }
//    }

    @GetMapping("/settings/deleteUserRoleByID/{id}")
    public ModelAndView deleteUserRoleByID(@PathVariable("id") Integer userRoleID){
        try {
            userRoleRepository.deleteByRole_id(userRoleID);
            return new ModelAndView("redirect:/admin/settings/userRoleList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }
}
