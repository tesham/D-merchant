package com.dmerchant.dmerchant.controller.admin.settings.productCategory;

import com.dmerchant.dmerchant.model.ProductCategory;
import com.dmerchant.dmerchant.repository.ProductCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class ProductCategoryController {
    @Autowired
    ProductCategoryRepository productCategoryRepository;
    @GetMapping("/settings/productCategoryList")
    public ModelAndView productCategoryList(){
        try {
            ModelAndView model = new ModelAndView("Settings/ProductCategory/ProductCategoryList");
            List<ProductCategory> productCategories = (List<ProductCategory>)productCategoryRepository.findAll();
            model.addObject("productCategoryList", productCategories);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/addProductCategory")
    public ModelAndView addProductCategory(@RequestParam("productCategoryName") String productCategoryName){
        try {
            ProductCategory productCategory = new ProductCategory();
            productCategory.setProduct_category_name(productCategoryName);
            productCategory.setInsert_time(new Date());
            productCategoryRepository.save(productCategory);
            return new ModelAndView("redirect:/admin/settings/productCategoryList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @GetMapping("/settings/editProductCategoryByID/{id}")
    public ModelAndView editProductCategoryByID(@PathVariable("id") Integer productCategoryID){
        try {
            ModelAndView model = new ModelAndView("Settings/ProductCategory/EditProductCategory");
            ProductCategory productCategory = productCategoryRepository.findByProductCategory_id(productCategoryID);
            model.addObject("productCategoryByID", productCategory);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/editProductCategory")
    public ModelAndView SubmitEditProductCategory(@RequestParam("productCategoryID") Integer productCategoryID,
                                        @RequestParam("productCategoryName") String productCategoryName){
        try {
//            Brand brand = new Brand();
            productCategoryRepository.updateProductCategoryName(productCategoryName,productCategoryID);
            return new ModelAndView("redirect:/admin/settings/productCategoryList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @GetMapping("/settings/deleteProductCategoryByID/{id}")
    public ModelAndView deleteProductCategoryByID(@PathVariable("id") Integer productCategoryID){
        try {
            productCategoryRepository.deleteByProductCategory_id(productCategoryID);
            return new ModelAndView("redirect:/admin/settings/productCategoryList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageCategoryCanNotBeDeleted");
        }
    }
}
