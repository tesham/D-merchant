package com.dmerchant.dmerchant.model;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.*;
import java.util.Base64;
import java.util.Date;

@Entity
@Table(name = "product_image")
public class ProductImage {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "product_image_id")
    private Integer product_image_id;
    @Column(name = "product_id")
    private Integer product_id;
//    @Column(name = "image")
//    private byte [] image;MultipartFile
    @Column(name = "image")
  //  private MultipartFile image;
    private byte [] image;
    @Column(name = "is_active")
    private Integer is_active;
    @Column(name = "is_title")
    private Integer is_title;
    @Column(name = "created_at")
    private Date createDate;

    public Integer getProduct_image_id() {
        return product_image_id;
    }

    public void setProduct_image_id(Integer product_image_id) {
        this.product_image_id = product_image_id;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }

    public byte [] getImage() {
        return image;
    }

    public void setImage(byte [] image) {
        this.image = image;
    }

    public Integer getIs_active() {
        return is_active;
    }

    public void setIs_active(Integer is_active) {
        this.is_active = is_active;
    }

    public Integer getIs_title() {
        return is_title;
    }

    public void setIs_title(Integer is_title) {
        this.is_title = is_title;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

//    public String getBase64String(){
//        try {
//            return new String(Base64.getEncoder().encode(getImage()), "UTF-8");
//        }catch (Exception e){
//            return null;
//        }
//
//    }
}
