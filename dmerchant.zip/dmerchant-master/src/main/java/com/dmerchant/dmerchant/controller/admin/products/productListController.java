package com.dmerchant.dmerchant.controller.admin.products;

import com.dmerchant.dmerchant.model.*;
import com.dmerchant.dmerchant.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.Console;
import java.sql.Blob;
import java.util.Base64;
import java.util.List;

@Controller
@RequestMapping("admin")
public class productListController {
    @Autowired
    InventoryRepository inventoryRepository;
    @Autowired
    ProductCategoryRepository productCategoryRepository;
    @Autowired
    ProductSubCategoryRepository productSubCategoryRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ProductImageRepository productImageRepository;
    @Autowired
    BrandRepository brandRepository;

    @GetMapping("productList")
    public ModelAndView GetProductAllList(){
        try {
            ModelAndView model = new ModelAndView("Admin/Products/addProducts");
            List<Product> productList = (List<Product>)productRepository.findAll();
            List<ProductCategory> productCategoryList = (List<ProductCategory>)productCategoryRepository.findAll();
            List<ProductSubCategory> productSubCategoryList = (List<ProductSubCategory>)productSubCategoryRepository.findAll();
            List<Brand> brandList = (List<Brand>)brandRepository.findAll();
//            List<ProductImage> productImages = (List<ProductImage>)productImageRepository.findAll();
//            to test for showing image in datatable
//            ProductImage productImages = productImageRepository.findByProduct_id(13);
//            byte[] productImage = Base64.getEncoder().encode(productImages.getImage());
//            Blob imageBlob = resultSet
            model.addObject("productAllList",productList);
            model.addObject("productCategoryList", productCategoryList);
            model.addObject("productSubCategoryList", productSubCategoryList);
            model.addObject("brandList", brandList);
//            model.addObject("productImage",productImage);
//            model.addObject("productImage",Base64.getEncoder().encodeToString(productImages.getImage()));
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }

    }

//    @GetMapping("/addProduct")
//    public ModelAndView addProduct(@RequestParam("contactNo") String contactNo,
//                                   @RequestParam("asdf") byte [] asdf,
//                                   @RequestParam("wer") String wer){
//        try {
////            ModelAndView model = new ModelAndView("Products/addProduct");
////            return model;
//            return new ModelAndView("redirect:admin/productList");
//        }catch (Exception ex){
//            System.err.println(ex);
//            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhileLabel");
//        }
//    }
}
