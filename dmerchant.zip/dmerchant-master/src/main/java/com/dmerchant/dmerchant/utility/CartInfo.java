package com.dmerchant.dmerchant.utility;

import com.dmerchant.dmerchant.model.OrderInfo;
import com.dmerchant.dmerchant.model.Product;

import java.util.ArrayList;
import java.util.List;

public class CartInfo {
    private OrderDetails orderDetails;
    private final List<CartLineInfo> cartLines = new ArrayList<CartLineInfo>();

    public OrderDetails getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(OrderDetails orderDetails) {
        this.orderDetails = orderDetails;
    }

    public List<CartLineInfo> getCartLines() {
        return cartLines;
    }

    public CartLineInfo findByProductId(Integer id){
        for (CartLineInfo line: cartLines){
            if(line.getProduct().getProduct_id()==id){
                return  line;
            }
        }
        return null;
    }


    public void addProduct(Product product,int quantity){
        CartLineInfo cartLineInfo=this.findByProductId(product.getProduct_id());
        if(cartLineInfo==null){
            cartLineInfo=new CartLineInfo();
            cartLineInfo.setQuantity(0);
            cartLineInfo.setProduct(product);
            this.cartLines.add(cartLineInfo);
        }

        int newQuantity = cartLineInfo.getQuantity() + quantity;
        if (newQuantity <= 0) {
            this.cartLines.remove(cartLineInfo);
        } else {
            cartLineInfo.setQuantity(newQuantity);
        }

    }

    public void updateProduct(Integer productId,int quantity){
        CartLineInfo cartLineInfo=this.findByProductId(productId);
        if (cartLineInfo != null) {
            if (quantity <= 0) {
                this.cartLines.remove(cartLineInfo);
            } else {
                cartLineInfo.setQuantity(quantity);
            }
        }
    }

    public void removeProduct(Product product) {
        CartLineInfo line = this.findByProductId(product.getProduct_id());
        if (line != null) {
            this.cartLines.remove(line);
           // line.setAvailable(1);
        }
    }

    public void removeProducts() {
        this.cartLines.clear();
    }

    public boolean isEmpty() {
        return this.cartLines.isEmpty();
    }

    public int getQuantityTotal() {
        int quantity = 0;
        for (CartLineInfo line : this.cartLines) {
            quantity += line.getQuantity();
        }
        return quantity;
    }

    public double getAmountTotal() {
        double total = 0;
        for (CartLineInfo line : this.cartLines) {
            if(line.getProduct().getDiscountAvailable()){
                total+=line.getDiscountedAmmount();
            }else{
                total += line.getAmmount();
            }

        }
        return total;
    }

    public void updateQuantity(CartInfo cartForm) {
        if(cartForm!=null){
            List<CartLineInfo> lines = cartForm.getCartLines();
            for (CartLineInfo line : lines) {
                this.updateProduct(line.getProduct().getProduct_id(), line.getQuantity());
            }
        }
    }


}
