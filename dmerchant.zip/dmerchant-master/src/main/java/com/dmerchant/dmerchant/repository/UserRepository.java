package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
@Repository
public interface UserRepository extends CrudRepository<User,Integer> {

    @Query("SELECT u FROM User u WHERE u.email=:email ")
    Optional<User> findUser_nameAndAndIs_active(@Param("email") String email);
    @Query("SELECT u FROM User u WHERE u.user_id=:user_id ")
    User findByUser_id(@Param("user_id")  Integer user_id);

    @Modifying
    @Transactional
    @Query("DELETE from User r where r.user_id=:id")
    void deleteByUser_id(@Param("id") Integer id);
}
