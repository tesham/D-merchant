package com.dmerchant.dmerchant.model;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "cart_product")
public class CartProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "cart_product_id")
    private Integer cart_product_id;
    @Column(name = "product_id")
    private Integer product_id;
    @Column(name = "cart_id")
    private Integer cart_id;
    @Column(name = "product_count")
    private Integer productCount;

//    @OneToMany(fetch =FetchType.EAGER,targetEntity = Product.class)
//    @JoinColumn(name = "product_id", insertable = false, updatable = false)
//    private List<Product> products;

    @OneToOne(fetch =FetchType.EAGER,targetEntity = Product.class)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    @OneToOne (fetch = FetchType.EAGER,targetEntity = Cart.class)
    @JoinColumn(name = "cart_id", insertable = false, updatable = false)
    private Cart cart;

    public Integer getCart_product_id() {
        return cart_product_id;
    }

    public void setCart_product_id(Integer cart_product_id) {
        this.cart_product_id = cart_product_id;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }

    public Integer getCart_id() {
        return cart_id;
    }

    public void setCart_id(Integer cart_id) {
        this.cart_id = cart_id;
    }

    public Integer getProductCount() {
        return productCount;
    }

    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }

//    public List<Product> getProducts() {
//        return products;
//    }
//
//    public void setProducts(List<Product> products) {
//        this.products = products;
//    }


    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }
}
