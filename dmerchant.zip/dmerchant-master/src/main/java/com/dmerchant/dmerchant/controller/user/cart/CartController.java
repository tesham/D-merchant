package com.dmerchant.dmerchant.controller.user.cart;

import com.dmerchant.dmerchant.model.Product;
import com.dmerchant.dmerchant.repository.ProductRepository;
import com.dmerchant.dmerchant.session.Utils;
import com.dmerchant.dmerchant.utility.CartInfo;
import com.dmerchant.dmerchant.utility.CartLineInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("cart")
public class CartController {
    @Autowired
    ProductRepository productRepository;

    @PostMapping("/addToCart")
    public String addProductToCart(
            HttpServletRequest request,
            @RequestParam("productId") Integer productId
    ){
       // int checkAddedCartQty=0;
        //int availablity=0;
        Product product=productRepository.findByProduct_id(productId);
        if(product!=null){
            CartInfo cartInfo= Utils.getCartInSession(request);
            //CartLineInfo cartLineInfo=cartInfo.findByProductId(productId);
//            if(cartLineInfo!=null){
//                checkAddedCartQty=cartLineInfo.getQuantity();
//            }
          //  if(product.getInventory().getTotalStocked()>=1+checkAddedCartQty){
                cartInfo.addProduct(product,1);
           // }else {
               // availablity=1;
            //}
            //request.getSession().setAttribute("availablityOnSingle",availablity);
           // cartInfo.addProduct(product,1);
        }
        return "redirect:/products/subcategory/"+product.getProduct_sub_category_id();
    }

    @GetMapping("/removeFromCart/{id}")
    public void removeProductFrmCart(
            HttpServletRequest request,
            @PathVariable("id") String productId
    ){
        Integer tempId=Integer.parseInt(productId);
        Product product=productRepository.findByProduct_id(tempId);
        if(product!=null){
            CartInfo cartInfo= Utils.getCartInSession(request);
            cartInfo.removeProduct(product);
        }
       // return null;
    }

    @PostMapping("/addProduct")
    public String addProducts(
            HttpServletRequest request,
            @RequestParam(value = "qty",defaultValue = "0") int quantity,
            @RequestParam("productId") Integer productId
    ){
        //int checkAddedCartQty=0;
       // int availablity=0;
        Product product=productRepository.findByProduct_id(productId);
        if(product!=null){
            CartInfo cartInfo= Utils.getCartInSession(request);
           // CartLineInfo cartLineInfo=cartInfo.findByProductId(productId);
//            if(cartLineInfo!=null){
//                checkAddedCartQty=cartLineInfo.getQuantity();
//            }
//            if(product.getInventory().getTotalStocked()>=quantity+checkAddedCartQty){
            if(quantity>0){
                cartInfo.addProduct(product,quantity);
            }

//            }else {
//                availablity=1;
//            }
//            request.getSession().setAttribute("availablity",availablity);

        }
        return "redirect:/products/product/"+product.getProduct_id();
    }

    

}
