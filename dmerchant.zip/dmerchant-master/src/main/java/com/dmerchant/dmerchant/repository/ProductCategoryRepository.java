package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.ProductCategory;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ProductCategoryRepository extends CrudRepository<ProductCategory,Integer> {
    @Query("SELECT u from ProductCategory u where u.product_category_id=:id")
    ProductCategory findByProductCategory_id(@Param("id") Integer id);

    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE ProductCategory p set p.product_category_name=:productCategoryName where p.product_category_id=:id")
    void updateProductCategoryName(@Param("productCategoryName") String productCategoryName,
                                   @Param("id") Integer id);

    @Modifying
    @Transactional(readOnly = false)
    @Query("DELETE from  ProductCategory p where p.product_category_id=:id")
    void deleteByProductCategory_id(@Param("id") Integer id);
}
