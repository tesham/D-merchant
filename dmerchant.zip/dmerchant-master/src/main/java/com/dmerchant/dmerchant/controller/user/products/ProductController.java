package com.dmerchant.dmerchant.controller.user.products;

import com.dmerchant.dmerchant.model.Product;
import com.dmerchant.dmerchant.model.ProductReview;
import com.dmerchant.dmerchant.repository.ProductRepository;
import com.dmerchant.dmerchant.repository.ProductReviewRepository;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.persistence.criteria.CriteriaBuilder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Controller
//@SessionAttributes("list")
@RequestMapping("products")
public class ProductController {

    @Autowired
    ProductRepository productRepository;
    @Autowired
    ProductReviewRepository productReviewRepository;

    public  int size=1;

    //@GetMapping("subcategory/{id}"
    @RequestMapping(value = {"subcategory/{id}", "subcategory/{id}/{pageNo}"})
    public ModelAndView getProductList(
            @PathVariable("id") Integer subId,
            HttpServletRequest   request
    ){
        Pageable firstPage =null;
        int page=0;
       // int size=1;
        if (request.getParameter("page") != null && !request.getParameter("page").isEmpty()) {
            page = Integer.parseInt(request.getParameter("page")) - 1;
        }
        if (request.getParameter("size") != null && !request.getParameter("size").isEmpty()) {
            setSize(Integer.parseInt(request.getParameter("size")));
        }

        size=this.getSize();

        firstPage = PageRequest.of(page, size);


        ModelAndView model=new ModelAndView("Products/products");
        Page<Product> pageProducts=productRepository.getAllByProductSubCategory(subId,firstPage);
        int totalPages=pageProducts.getTotalPages();
      //  int num=pageProducts.getNumber();
        if(totalPages>0){
            List<Integer> pageNumbers = IntStream.rangeClosed(1,totalPages).boxed().collect(Collectors.toList());
            model.addObject("pageNumbers", pageNumbers);
            model.addObject("subcatId", subId);
        }
        //model a return korrte hbe , debug kore data paisi
        model.addObject("productList",pageProducts);
        return model;
    }


//    @PostMapping(value = {"subcategory/{id}"})
//    public ModelAndView getAmountedProductList(
//            @PathVariable("id") Integer subId,
//            @RequestParam("size") Integer size
//    ){
//        Pageable firstPage =null;
//        firstPage = PageRequest.of(0, size);
//
//
//
//        ModelAndView model=new ModelAndView("Products/products");
//        Page<Product> pageProducts=productRepository.getAllByProductSubCategory(subId,firstPage);
//        int totalPages=pageProducts.getTotalPages();
//        if(totalPages>0){
//            List<Integer> pageNumbers = IntStream.rangeClosed(1,totalPages).boxed().collect(Collectors.toList());
//            model.addObject("pageNumbers", pageNumbers);
//            model.addObject("subcatId", subId);
//        }
//        //model a return korrte hbe , debug kore data paisi
//        model.addObject("productList",pageProducts.getContent());
//        return model;
//    }



    @GetMapping("product/{id}")
    public ModelAndView getProduct(
            @PathVariable("id") Integer productId
    ){
        ModelAndView model=new ModelAndView("Products/product_page");
        Product product=productRepository.findByProduct_id(productId);
        List<ProductReview> productReviews=productReviewRepository.findByProductId(productId);
        model.addObject("product",product);
        model.addObject("productReviews",productReviews);
        return model;
    }

    @PostMapping("product/review")
    public String postReview(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("review") String review,
            @RequestParam(value = "rating",defaultValue = "5") Integer rating,
            @RequestParam("productId") Integer productId
    ){
        ProductReview productReview=new ProductReview();
        productReview.setName(name);
        productReview.setEmail(email);
        productReview.setReview(review);
        productReview.setGivenStar(rating);
        productReview.setProductId(productId);
        productReview.setCreatedAt(new Date());
        productReviewRepository.save(productReview);
        return "redirect:/products/product/"+productId;
    }

    @RequestMapping(value = "productImage/{productId}",produces = MediaType.IMAGE_JPEG_VALUE)
    public ResponseEntity<byte[]> getProductImage(
            @PathVariable("productId") Integer productId
    ) throws ServletException, IOException, SQLException {
        Product product=productRepository.findByProduct_id(productId);
        return ResponseEntity
                .ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(product.getImages().get(0).getImage());

    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
