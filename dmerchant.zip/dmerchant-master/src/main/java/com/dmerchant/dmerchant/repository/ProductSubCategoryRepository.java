package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.ProductSubCategory;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProductSubCategoryRepository extends CrudRepository<ProductSubCategory,Integer> {
    @Query
    ("select u from ProductSubCategory u where u.product_category_id=:id")
    List<ProductSubCategory> getAllByProduct_category_id(
            @Param("id") Integer id
    );

    @Query("SELECT u from ProductSubCategory u where u.product_sub_category_id=:id")
    ProductSubCategory findByProductSubCategory_id(@Param("id") Integer id);

    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE ProductSubCategory p set p.product_sub_category_name=:productSubCategoryName, p.product_category_id=:productCategoryID where p.product_sub_category_id=:id")
    void updateProductSubCategory(@Param("productSubCategoryName") String productSubCategoryName,
                                  @Param("productCategoryID") Integer productCategoryID,
                                  @Param("id") Integer productSubCategoryID);

    @Modifying
    @Transactional(readOnly = false)
    @Query("DELETE from ProductSubCategory p where p.product_sub_category_id=:id")
    void deleteByProductSubCategory_id(@Param("id") Integer productSubCategoryID);
}
