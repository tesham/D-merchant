package com.dmerchant.dmerchant.controller.admin.products;

import com.dmerchant.dmerchant.model.Brand;
import com.dmerchant.dmerchant.model.Product;
import com.dmerchant.dmerchant.model.ProductCategory;
import com.dmerchant.dmerchant.model.ProductSubCategory;
import com.dmerchant.dmerchant.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class editProductController {
    @Autowired
    InventoryRepository inventoryRepository;
    @Autowired
    ProductCategoryRepository productCategoryRepository;
    @Autowired
    ProductSubCategoryRepository productSubCategoryRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ProductImageRepository productImageRepository;
    @Autowired
    BrandRepository brandRepository;

    @GetMapping("/editProductByID/{id}")
    ModelAndView editProductByID(@PathVariable("id") Integer productID){
        try {
            ModelAndView model = new ModelAndView("Admin/Products/editProducts");
            Product product = productRepository.findByProduct_id(productID);
           // List<ProductCategory> productCategoryList = (List<ProductCategory>)productCategoryRepository.findAll();
            //List<ProductSubCategory> productSubCategoryList = (List<ProductSubCategory>)productSubCategoryRepository.findAll();
           // List<Brand> brandList = (List<Brand>)brandRepository.findAll();
            model.addObject("product",product);
            //model.addObject("productCategoryList", productCategoryList);
           // model.addObject("productSubCategoryList", productSubCategoryList);
           // model.addObject("brandList", brandList);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/editProduct")
    public String editProduct(
                            @RequestParam("productId") Integer productId,
                             @RequestParam("productSN") String productSN,
                             @RequestParam("productName") String productName,
                             @RequestParam("productPrice") Double productPrice,
//                             @RequestParam("productDiscountAvailable") Boolean productDiscountAvailable,
                             @RequestParam("productDiscount") Double productDiscount,
                             @RequestParam("productDescription") String productDescription,
                             @RequestParam(value = "file",required = false) MultipartFile productImage,
                             @RequestParam("totalStock") Integer totalStock,
                             HttpServletRequest request
    ){

        Product product=productRepository.findByProduct_id(productId);
        try {
            if(!productImage.isEmpty()){
                productImageRepository.updateProductImage(productId,productImage.getBytes());
            }

        }catch (Exception e){}

        productRepository.updateProduct(productId,productSN,productName,productPrice,productDiscount,productDescription);

        inventoryRepository.updateProductInventory(product.getInventory().getInventory_id(),totalStock);

        return "redirect:/admin/productList";

    }



}
