package com.dmerchant.dmerchant.model;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "product_id")
    private Integer product_id;
    @Column(name = "brand_id")
    private Integer brand_id;
    @Column(name = "product_sub_category_id")
    private Integer product_sub_category_id;
    @Column(name = "inventory_id")
    private Integer inventory_id;
    @Column(name = "product_sn")
    private String productSN;
    @Column(name = "product_name")
    private String productName;
    @Column(name = "product_price")
    private Double productPrice;
    @Column(name = "is_discount_available")
    private Boolean isDiscountAvailable;
    @Column(name = "product_discount_percentage")
    private Double productDiscount;
    @Column(name = "insert_time")
    private Date insert_time;
    @Column(name = "product_description")
    private String productDescription;
    @Column(name = "user_id")
    private Integer user_id;
    @Column(name = "product_review_star_id")
    private Integer product_review_star_id;



    @OneToOne (fetch = FetchType.EAGER,targetEntity = ProductStar.class)
    @JoinColumn(name = "product_review_star_id", insertable = false, updatable = false)
    private ProductStar productStar;

    @OneToOne (fetch = FetchType.EAGER,targetEntity = ProductSubCategory.class)
    @JoinColumn(name = "product_sub_category_id", insertable = false, updatable = false)
    private ProductSubCategory productSubCategory;


    @OneToOne (fetch = FetchType.EAGER,targetEntity = Brand.class)
    @JoinColumn(name = "brand_id", insertable = false, updatable = false)
    private Brand brand;

    @OneToMany(fetch =FetchType.EAGER,targetEntity = ProductImage.class)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private List<ProductImage> images;

    @OneToOne (fetch = FetchType.EAGER,targetEntity = Inventory.class)
    @JoinColumn(name = "inventory_id", insertable = false, updatable = false)
    private Inventory inventory ;

    @OneToOne (fetch = FetchType.EAGER,targetEntity = User.class)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private User user ;

    public Integer getInventory_id() {
        return inventory_id;
    }

    public void setInventory_id(Integer inventory_id) {
        this.inventory_id = inventory_id;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public List<ProductImage> getImages() {
        return images;
    }

    public void setImages(List<ProductImage> images) {
        this.images = images;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }

    public Integer getBrand_id() {
        return brand_id;
    }

    public void setBrand_id(Integer brand_id) {
        this.brand_id = brand_id;
    }

    public Integer getProduct_sub_category_id() {
        return product_sub_category_id;
    }

    public void setProduct_sub_category_id(Integer product_sub_category_id) {
        this.product_sub_category_id = product_sub_category_id;
    }

    public String getProductSN() {
        return productSN;
    }

    public void setProductSN(String productSN) {
        this.productSN = productSN;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice = productPrice;
    }

    public Boolean getDiscountAvailable() {
        return isDiscountAvailable;
    }

    public void setDiscountAvailable(Boolean discountAvailable) {
        isDiscountAvailable = discountAvailable;
    }

    public Double getProductDiscount() {
        return productDiscount;
    }

    public void setProductDiscount(Double productDiscount) {
        this.productDiscount = productDiscount;
    }

    public Date getInsert_time() {
        return insert_time;
    }

    public void setInsert_time(Date insert_time) {
        this.insert_time = insert_time;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public ProductSubCategory getProductSubCategory() {
        return productSubCategory;
    }

    public void setProductSubCategory(ProductSubCategory productSubCategory) {
        this.productSubCategory = productSubCategory;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getProduct_review_star_id() {
        return product_review_star_id;
    }

    public void setProduct_review_star_id(Integer product_review_star_id) {
        this.product_review_star_id = product_review_star_id;
    }

    public ProductStar getProductStar() {
        return productStar;
    }

    public void setProductStar(ProductStar productStar) {
        this.productStar = productStar;
    }
}
