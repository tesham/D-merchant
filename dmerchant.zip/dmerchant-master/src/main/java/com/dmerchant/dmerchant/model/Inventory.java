package com.dmerchant.dmerchant.model;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "inventory")
public class Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "inventory_id")
    private Integer inventory_id;
    @Column(name = "total_stocked")
    private Integer totalStocked;
    @Column(name = "total_sold")
    private Integer totalSold;
    @Column(name = "is_available")
    private Boolean isAvailable;
    @Column(name = "can_sell")
    private Boolean canSell;


    public Integer getInventory_id() {
        return inventory_id;
    }

    public void setInventory_id(Integer inventory_id) {
        this.inventory_id = inventory_id;
    }


    public Integer getTotalStocked() {
        return totalStocked;
    }

    public void setTotalStocked(Integer totalStocked) {
        this.totalStocked = totalStocked;
    }

    public Integer getTotalSold() {
        return totalSold;
    }

    public void setTotalSold(Integer totalSold) {
        this.totalSold = totalSold;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

    public Boolean getCanSell() {
        return canSell;
    }

    public void setCanSell(Boolean canSell) {
        this.canSell = canSell;
    }

}
