package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.ProductImage;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ProductImageRepository extends CrudRepository<ProductImage,Integer> {
//    to test for product image
    @Query("SELECT u from ProductImage u where u.product_id=:id")
    ProductImage findByProduct_id(@Param("id") Integer id);

    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE ProductImage b set b.image=:image where b.product_id=:id")
    void updateProductImage(
            @Param("id") Integer id,
            @Param("image") byte [] image
    );

}
