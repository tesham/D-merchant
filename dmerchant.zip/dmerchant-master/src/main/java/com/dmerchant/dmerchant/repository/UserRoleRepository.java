package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.Role;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;


public interface UserRoleRepository extends CrudRepository<Role, Integer> {
    @Query("SELECT u from Role u where u.role_id=:id")
    Role findByRole_id(@Param("id") Integer id);

//    @Modifying
//    @Transactional(readOnly = false)
//    void updateUserRoleByID();
    @Modifying
    @Transactional
    @Query("DELETE from Role r where r.role_id=:id")
    void deleteByRole_id(@Param("id") Integer id);

}
