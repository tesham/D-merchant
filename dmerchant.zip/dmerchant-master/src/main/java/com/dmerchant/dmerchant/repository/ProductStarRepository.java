package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.ProductStar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductStarRepository extends JpaRepository<ProductStar,Integer> {
}
