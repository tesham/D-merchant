package com.dmerchant.dmerchant.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "product_category")
public class ProductCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "product_category_id")
    private Integer product_category_id;
    @Column(name = "product_category_name")
    private String 	product_category_name;
    @Column(name = "insert_time")
    private Date insert_time;

    @OneToMany(fetch = FetchType.EAGER,targetEntity =ProductSubCategory.class)
    @JoinColumn(name = "product_category_id", insertable = false, updatable = false)
    private List<ProductSubCategory> productSubCategories;

    public List<ProductSubCategory> getProductSubCategories() {
        return productSubCategories;
    }

//    public void setProductSubCategories(List<ProductSubCategory> productSubCategories) {
//        this.productSubCategories = productSubCategories;
//    }

    public Integer getProduct_category_id() {
        return product_category_id;
    }

    public void setProduct_category_id(Integer product_category_id) {
        this.product_category_id = product_category_id;
    }

    public String getProduct_category_name() {
        return product_category_name;
    }

    public void setProduct_category_name(String product_category_name) {
        this.product_category_name = product_category_name;
    }

    public Date getInsert_time() {
        return insert_time;
    }

    public void setInsert_time(Date insert_time) {
        this.insert_time = insert_time;
    }
}
