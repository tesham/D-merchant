package com.dmerchant.dmerchant.controller.admin.settings.user;

import com.dmerchant.dmerchant.model.Role;
import com.dmerchant.dmerchant.model.User;
import com.dmerchant.dmerchant.repository.UserRepository;
import com.dmerchant.dmerchant.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class UserSettingsController {
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserRoleRepository userRoleRepository;

    @GetMapping("/settings/userList")
    public ModelAndView userList(){
        try {
            ModelAndView model = new ModelAndView("Settings/User/UserList");
            List<User> users = (List<User>)userRepository.findAll();
            List<Role> userRoles = (List<Role>)userRoleRepository.findAll();
            model.addObject("userList",users);
            model.addObject("userRoleList",userRoles);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping("/addUser")
    public ModelAndView addUserFrmHeader(){
        List<Role> userRoles = (List<Role>)userRoleRepository.findAll();
        ModelAndView model = new ModelAndView("Settings/User/addUser");
        model.addObject("userRoleList",userRoles);
        return model;
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/settings/addUser")
    public String addUser(@RequestParam("firstName") String firstName,
                                @RequestParam("lastName") String lastName,
                                @RequestParam("email") String email,
                                @RequestParam("password") String password,
                                @RequestParam("isActive") Boolean isActive,
                                @RequestParam("roleId") Integer roleId,
                                @RequestParam("image")MultipartFile image){
        try {
            User user = new User();
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setEmail(email);
            user.setPassword(password);
            user.setActive(isActive);
            user.setRole_id(roleId);
            user.setImage(image.getBytes());
            user.setCreatedAt(new Date());
            userRepository.save(user);

            return ("redirect:/admin/settings/userList");
        }catch (Exception ex){
            System.err.println(ex);
//            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
        return "d";
    }


    @PreAuthorize("hasAnyRole('ADMIN')")
    @Transactional(rollbackFor = Exception.class)
    @GetMapping("/deleteUser/{id}")
    public String deleteUser(@PathVariable("id") Integer userId){
        userRepository.deleteByUser_id(userId);
        return "redirect:/admin/settings/userList";
    }


    @RequestMapping(value = "userImage/{userId}",produces = MediaType.IMAGE_JPEG_VALUE)
    public ResponseEntity<byte[]> getUserImage(
            @PathVariable("userId") Integer userId
    ) throws ServletException, IOException, SQLException {
        User user=userRepository.findByUser_id(userId);
        return ResponseEntity
                .ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(user.getImage());

    }

}
