package com.dmerchant.dmerchant.model;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "order_info")
public class OrderInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "order_info_id")
    private Integer orderInfoId;
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "customer_phone")
    private String customerPhone;
    @Column(name = "customer_mail")
    private String customerMail;
    @Column(name = "customer_address")
    private String customerAddress;
    @Column(name = "order_date")
    private Date orderDate;
    @Column(name = "cart_id")
    private Integer cartId;
    @Column(name = "is_buy")
    private Integer isBuy;

    @OneToOne (fetch = FetchType.EAGER,targetEntity = Cart.class)
    @JoinColumn(name = "cart_id", insertable = false, updatable = false)
    private Cart cart;

    public Cart getCart() {
        return cart;
    }

    public Integer getOrderInfoId() {
        return orderInfoId;
    }

    public void setOrderInfoId(Integer orderInfoId) {
        this.orderInfoId = orderInfoId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getCustomerMail() {
        return customerMail;
    }

    public void setCustomerMail(String customerMail) {
        this.customerMail = customerMail;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public Integer getBuy() {
        return isBuy;
    }

    public void setBuy(Integer buy) {
        isBuy = buy;
    }
}
