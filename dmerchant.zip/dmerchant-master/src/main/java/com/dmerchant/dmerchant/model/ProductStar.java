package com.dmerchant.dmerchant.model;

import javax.persistence.*;

@Entity
@Table(name = "product_review_star")
public class ProductStar {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "product_review_star_id")
    private Integer product_review_star_id;
    @Column(name = "star_sum")
    private Integer star_sum;
    @Column(name = "star_given_count")
    private Integer star_given_count;
    @Column(name = "rating")
    private Integer rating;

    public Integer getProduct_review_star_id() {
        return product_review_star_id;
    }

    public void setProduct_review_star_id(Integer product_review_star_id) {
        this.product_review_star_id = product_review_star_id;
    }


    public Integer getStar_sum() {
        return star_sum;
    }

    public void setStar_sum(Integer star_sum) {
        this.star_sum = star_sum;
    }

    public Integer getStar_given_count() {
        return star_given_count;
    }

    public void setStar_given_count(Integer star_given_count) {
        this.star_given_count = star_given_count;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }
}
