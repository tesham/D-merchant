package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.CartProduct;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CartProductRepository extends CrudRepository<CartProduct, Integer> {
    @Query("select p from CartProduct p where p.cart_id=:id")
   List<CartProduct> findByCart_id(@Param("id") Integer cartID);
//    List<CartProduct> findByCart_id(@Param("id") Integer cartID);
}
