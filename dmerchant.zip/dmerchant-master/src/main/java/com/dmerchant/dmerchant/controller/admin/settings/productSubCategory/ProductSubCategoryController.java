package com.dmerchant.dmerchant.controller.admin.settings.productSubCategory;

import com.dmerchant.dmerchant.model.ProductCategory;
import com.dmerchant.dmerchant.model.ProductSubCategory;
import com.dmerchant.dmerchant.repository.ProductCategoryRepository;
import com.dmerchant.dmerchant.repository.ProductSubCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class ProductSubCategoryController {
    @Autowired
    ProductCategoryRepository productCategoryRepository;
    @Autowired
    ProductSubCategoryRepository productSubCategoryRepository;

    @GetMapping("/settings/productSubCategoryList")
    public ModelAndView productSubCategoryList(){
        try {
            ModelAndView model = new ModelAndView("Settings/ProductSubCategory/ProductSubCategoryList");
            List<ProductSubCategory> productSubCategories = (List<ProductSubCategory>)productSubCategoryRepository.findAll();
            List<ProductCategory> productCategories = (List<ProductCategory>)productCategoryRepository.findAll();
            model.addObject("productCategoryList", productCategories);
            model.addObject("productSubCategoryList", productSubCategories);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/addProductSubCategory")
    public ModelAndView addProductSubCategory(@RequestParam("productSubCategoryName") String productSubCategoryName,
                                              @RequestParam("productCategory") Integer productCategoryID){
        try {
            ProductSubCategory productSubCategory = new ProductSubCategory();
            productSubCategory.setProduct_sub_category_name(productSubCategoryName);
            productSubCategory.setProduct_category_id(productCategoryID);
            productSubCategory.setInsert_time(new Date());
            productSubCategoryRepository.save(productSubCategory);
            return new ModelAndView("redirect:/admin/settings/productSubCategoryList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @GetMapping("/settings/editProductSubCategoryByID/{id}")
    public ModelAndView editProductSubCategoryByID(@PathVariable("id") Integer productSubCategoryID){
        try {
            ModelAndView model = new ModelAndView("Settings/ProductSubCategory/EditProductSubCategory");
            ProductSubCategory productSubCategory = productSubCategoryRepository.findByProductSubCategory_id(productSubCategoryID);
            List<ProductCategory> productCategories = (List<ProductCategory>)productCategoryRepository.findAll();
            model.addObject("productCategoryList", productCategories);
            model.addObject("productSubCategoryByID", productSubCategory);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @PostMapping("/settings/editProductSubCategory")
    public ModelAndView SubmitEditProductSubCategory(@RequestParam("productSubCategoryID") Integer productSubCategoryID,
                                                     @RequestParam("productSubCategoryName") String productSubCategoryName,
                                                     @RequestParam("productCategory") Integer productCategoryID){
        try {
            productSubCategoryRepository.updateProductSubCategory(productSubCategoryName,productCategoryID,productSubCategoryID);
            return new ModelAndView("redirect:/admin/settings/productSubCategoryList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @GetMapping("/settings/deleteProductSubCategoryByID/{id}")
    public ModelAndView deleteProductSubCategoryByID(@PathVariable("id") Integer productSubCategoryID){
        try {
            productSubCategoryRepository.deleteByProductSubCategory_id(productSubCategoryID);
            return new ModelAndView("redirect:/admin/settings/productSubCategoryList");
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }
}
