package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.OrderInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface OrderInfoRepository extends CrudRepository<OrderInfo, Integer> {
    @Query("SELECT u FROM OrderInfo u")
    List<OrderInfo> getAllOrders(@Param("is_buy") Integer is_buy);

    @Query("SELECT u FROM OrderInfo u where u.orderInfoId=:orderId ")
    OrderInfo findByOrderInfoIdAndBuy(@Param("orderId") Integer orderInfo);
}
