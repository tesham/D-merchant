package com.dmerchant.dmerchant.controller.admin.otherSettings;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("")
public class aboutUsController {
    @GetMapping("/aboutUs")
    public ModelAndView aboutUsIndex(){
        try {
            ModelAndView model = new ModelAndView("Admin/OtherSettings/AboutUs/AboutUsIndex");
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }
}
