package com.dmerchant.dmerchant.controller.admin;

import com.dmerchant.dmerchant.utility.JsonData;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import javassist.bytecode.stackmap.BasicBlock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;

@Controller
@RequestMapping("/admin")
public class adminIndexController {
    @GetMapping("/index")
    public ModelAndView GetAminIndex(){
        ModelAndView model  = new ModelAndView("Admin/adminIndex");
        return model;
    }

        @RequestMapping(value="/getpdf1", method= RequestMethod.GET)
    public ResponseEntity<byte[]> getPDF1() throws Exception {


        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.parseMediaType("application/pdf"));
        String filename = "pdf1.pdf";

        headers.add("content-disposition", "inline;filename=" + filename);

//        headers.setContentDispositionFormData(filename, filename);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
        ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(getPdfDoc(), headers, HttpStatus.OK);
        return response;
    }

        private byte[] getPdfDoc() throws Exception{
           Document document = new Document();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            PdfWriter.getInstance(document, stream);
            document.open();
             Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
            Chunk chunk = new Chunk("Hello World test", font);

            document.add(chunk);
            document.close();
            return stream.toByteArray();

    }
    @PostMapping("/testPDF")
    public void test (
            @RequestBody JsonData data,
            HttpServletResponse response,
            HttpServletRequest request
    ){
        String dsasad="sadasd";
        String temp=data.getData();
        byte[] pdf= Base64.getDecoder().decode(temp);

        try {
            OutputStream out = new FileOutputStream("D://out1.pdf");
            out.write(pdf);
            out.close();
        }catch (Exception e){}



        //String temp=data;
    }
}
