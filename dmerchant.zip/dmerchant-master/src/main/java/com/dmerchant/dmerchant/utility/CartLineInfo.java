package com.dmerchant.dmerchant.utility;

import com.dmerchant.dmerchant.model.Product;

public class CartLineInfo {
    private Product product;
    private int quantity;

   // private int available=1;

    public CartLineInfo(){
        this.quantity=0;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Double getAmmount(){
        return this.product.getProductPrice()*this.quantity;
    }

    public Double getDiscountedAmmount(){
        return (this.product.getProductPrice()-this.product.getProductPrice()*this.product.getProductDiscount())*this.quantity;
       // return this.product.getProductPrice()*this.quantity;
    }

//    public int getAvailable() {
//        return available;
//    }
//
//    public void setAvailable(int available) {
//        this.available = available;
//    }
}
