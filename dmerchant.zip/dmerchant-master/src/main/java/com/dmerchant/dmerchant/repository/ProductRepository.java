package com.dmerchant.dmerchant.repository;

import com.dmerchant.dmerchant.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product,Integer> {
    @Query("SELECT u FROM Product u where u.product_sub_category_id=:id")
    Page<Product> getAllByProductSubCategory(@Param("id") Integer id,Pageable pageable);

   // List<Product> findByProduct_sub_category_id(Integer id, Pageable pageable);

    @Query("SELECT u FROM Product u where u.product_id=:id")
    Product findByProduct_id(@Param("id") Integer id);


    @Modifying
    @Transactional(readOnly = false)
    @Query("UPDATE Product b set b.productSN=:productSN,b.productName=:productName,b.productPrice=:productPrice,b.productDiscount=:productDiscount,b.productDescription=:productDescription where b.product_id=:id")
    void updateProduct(
            @Param("id") Integer id,
            @Param("productSN") String productSN,
            @Param("productName") String productName,
            @Param("productPrice") Double productPrice,
            @Param("productDiscount") Double productDiscount,
            @Param("productDescription") String productDescription
    );


}
