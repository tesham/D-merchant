package com.dmerchant.dmerchant.controller.admin.authentication.login;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("")
public class LoginController {
    @GetMapping("/login")
    public ModelAndView loginIndex(
            @RequestParam(value = "error", required = false) String error
    ){
        try {

            String errorMessge = null;
            if(error != null) {
                errorMessge = "Username or Password is incorrect";
            }

            ModelAndView model = new ModelAndView("Authentication/Login/LoginIndex");
            model.addObject("errorMessge", errorMessge);
            return model;
        }catch (Exception ex){
            return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhiteLabel");
        }
    }

    @RequestMapping("/success")
    public void loginPageRedirect(HttpServletRequest request, HttpServletResponse response, Authentication authResult) throws IOException, ServletException {

        String role =  authResult.getAuthorities().toString();
        String userName=authResult.getName();
        request.getSession().setAttribute("userName",userName);
        request.getSession().setAttribute("userRole",role);
//        if(role.contains("ROLE_ADMIN")){
//            response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/admin/productList"));
//        }
        response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/admin/productList"));

    }
}
