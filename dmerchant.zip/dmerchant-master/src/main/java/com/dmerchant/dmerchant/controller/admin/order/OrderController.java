package com.dmerchant.dmerchant.controller.admin.order;

import com.dmerchant.dmerchant.model.CartProduct;
import com.dmerchant.dmerchant.model.OrderInfo;
import com.dmerchant.dmerchant.model.User;
import com.dmerchant.dmerchant.repository.CartProductRepository;
import com.dmerchant.dmerchant.repository.CartRepository;
import com.dmerchant.dmerchant.repository.OrderInfoRepository;
import com.dmerchant.dmerchant.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("admin")
public class OrderController {

    @Autowired
    OrderInfoRepository orderInfoRepository;
    @Autowired
    CartRepository cartRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    CartProductRepository cartProductRepository;

    @GetMapping("orders")
    public ModelAndView getOrders(){
        List<OrderInfo> orderInfos=orderInfoRepository.getAllOrders(0);
        ModelAndView model = new ModelAndView("Admin/order/orderInfo");
        model.addObject("orderInfos",orderInfos);
        return model;

    }

    @GetMapping("order/receive/{id}")
    public String receiveOrder(
            @PathVariable("id") Integer orderId,
            HttpServletRequest request
    ){
        OrderInfo orderInfo=orderInfoRepository.findByOrderInfoIdAndBuy(orderId);

        String userName=(String) request.getSession().getAttribute("userName");
        User user=userRepository.findUser_nameAndAndIs_active(userName).get();
        cartRepository.updateCartDeleverUser(user.getUser_id(),orderInfo.getCartId());

        //ModelAndView model = new ModelAndView("Admin/order/orderInfo");
      //  model.addObject("orderInfos",orderInfos);
        return "redirect:/admin/orders";
    }

    @GetMapping("order/productsByCartID/{orderInfoID}")
    public ModelAndView productsByCartID(
//                                            @PathVariable("cartID") Integer cartID,
                                         @PathVariable("orderInfoID") Integer orderInfoID){
        try {
            ModelAndView model = new ModelAndView("Admin/order/productListByCartID");
            OrderInfo orderInfo = orderInfoRepository.findByOrderInfoIdAndBuy(orderInfoID);
            List<CartProduct> cartProducts = cartProductRepository.findByCart_id(orderInfo.getCartId());
//            List<CartProduct> cartProducts = (List<CartProduct>) cartProductRepository.findByCart_id(cartID);
            double sumPrice=getSum(cartProducts);
            model.addObject("cartProducts",cartProducts);
            model.addObject("orderInfo",orderInfo);
            model.addObject("sumPrice",sumPrice);
            return model;
        }catch (Exception ex){
            System.err.println(ex);
        }
        return new ModelAndView("Shared/ErrorMessages/ErrorMessageWhileLabel");
    }

    private Double getSum(List<CartProduct> cartProducts){
        double sum=0;
        for(CartProduct cartProduct:cartProducts){
            sum=sum+cartProduct.getProductCount()*(cartProduct.getProduct().getProductPrice()-cartProduct.getProduct().getProductPrice()*cartProduct.getProduct().getProductDiscount());
        }
        return sum;
    }

}
