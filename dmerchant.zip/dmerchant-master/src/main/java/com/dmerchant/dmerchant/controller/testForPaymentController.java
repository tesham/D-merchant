package com.dmerchant.dmerchant.controller;

import com.dmerchant.dmerchant.model.Cart;
import com.dmerchant.dmerchant.model.CartProduct;
import com.dmerchant.dmerchant.model.OrderInfo;
import com.dmerchant.dmerchant.repository.CartProductRepository;
import com.dmerchant.dmerchant.repository.CartRepository;
import com.dmerchant.dmerchant.repository.OrderInfoRepository;
import com.dmerchant.dmerchant.session.Utils;
import com.dmerchant.dmerchant.utility.CartInfo;
import com.dmerchant.dmerchant.utility.CartLineInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Controller
@RequestMapping("paymentTest")
public class testForPaymentController {

    @Autowired
    CartRepository cartRepository;
    @Autowired
    OrderInfoRepository orderInfoRepository;
    @Autowired
    CartProductRepository cartProductRepository;


    @GetMapping("/paymentMethodSelectIndex")
    public ModelAndView selectPaymentMethod(){
        try {

            return new ModelAndView("Checkout/paymentMethodSelect");
//            ModelAndView model = new ModelAndView("Checkout/paymentMethodSelect");
//            return model;
        }catch (Exception ex){
            return new ModelAndView("redirect:Shared/ErrorMessages/ErrorMessageWhileLabel");
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/paymentMethodTest")
    public ModelAndView getPaymentMethodX(@RequestParam("paymentMethod") Integer paymentMethod,HttpServletRequest request){
        try {
//            paymentMethod = 1[CashOnDelivery];
//            paymentMethod = 2[bKash]
//            ModelAndView model = new ModelAndView("PaymentMethod/cashOnDelivery");
            if (paymentMethod == 1){
                CartInfo cartInfo= Utils.getCartInSession(request);
                if(cartInfo==null){
                    return new ModelAndView("redirect:Shared/ErrorMessages/ErrorMessageWhileLabel");
                }

                Cart cart=new Cart();
                //cart.setUser_id(1);
                cart.setBuy(false);
                cart.setCartStatus("processing");
                cart.setCreatedAt(new Date());
                cartRepository.save(cart);
                for(CartLineInfo cartLineInfo : cartInfo.getCartLines()){
                    CartProduct cartProduct=new CartProduct();
                    cartProduct.setCart_id(cart.getCart_id());
                    cartProduct.setProduct_id(cartLineInfo.getProduct().getProduct_id());
                    cartProduct.setProductCount(cartLineInfo.getQuantity());
                    cartProductRepository.save(cartProduct);
                }

                OrderInfo orderInfo=new OrderInfo();
                orderInfo.setCartId(cart.getCart_id());
                orderInfo.setCustomerAddress(cartInfo.getOrderDetails().getCustomerAddress());
                orderInfo.setCustomerMail(cartInfo.getOrderDetails().getCustomerMail());
                orderInfo.setCustomerName(cartInfo.getOrderDetails().getCustomerName());
                orderInfo.setCustomerPhone(cartInfo.getOrderDetails().getCustomerPhone());
                orderInfo.setOrderDate(new Date());
                orderInfo.setBuy(0);
                orderInfoRepository.save(orderInfo);

                cartInfo.removeProducts();

                return new ModelAndView("PaymentMethod/cashOnDelivery");
            }
            else if(paymentMethod == 2) {
                return new ModelAndView("PaymentMethod/bKash");
            }
            else {
                return new ModelAndView("redirect:Shared/ErrorMessageWrongPaymentMethod");
            }
        }catch (Exception ex){
            return new ModelAndView("redirect:Shared/ErrorMessages/ErrorMessageWhileLabel");
        }
    }
}
