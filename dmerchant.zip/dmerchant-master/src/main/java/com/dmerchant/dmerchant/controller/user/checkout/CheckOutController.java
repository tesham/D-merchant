package com.dmerchant.dmerchant.controller.user.checkout;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("cart")
public class CheckOutController {

    @GetMapping("viewCart")
    public ModelAndView viewCart(){
        ModelAndView model=new ModelAndView("Checkout/viewCart");
        return model;
    }

    @GetMapping("checkout")
    public ModelAndView viewCheckout(){
        ModelAndView model=new ModelAndView("Checkout/checkout");
        return model;
    }
}
